package org.jivesoftware.smack.packet;

public abstract class UnknownPacket
  extends Packet
  implements PacketExtension
{
  public String toXML()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("<").append(getElementName());
    if (getXmlns() != null) {
      localStringBuilder.append(" xmlns=\"").append(getNamespace()).append("\"");
    }
    localStringBuilder.append("/>");
    return localStringBuilder.toString();
  }
}
